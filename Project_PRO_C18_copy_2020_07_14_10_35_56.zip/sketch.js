//Global Variables
var backgr,backImage;
var ground,ground_img;

var player,player_running;
var bananaImage,fruitGroup;
var obstacle_img,obstacleGroup;

var gameover;
var score = 0;


function preload(){
  backImage = loadImage("jungle.jpg");
  
  player_running = loadImage("monkey_01.png","monkey_02.png","monkey_03.png","monkey_04.png","monkey_05.png","monkey_06.png","monkey_07.png","monkey_08.png","monkey_08.png","monkey_10.png");
  
  bananaImage = loadImage("Banana.png");
  obstacle_img = loadImage("stone.png");
}


function setup() {
  createCanvas(800,400);
  
  backgr = createSprite(0,0,800,400);
  backgr.addImage(backImage);
  backgr.scale = 1.5;
  backgr.x = backgr.width/2;
  backgr.velocityX = -6;
  
   player = createSprite(100,340,20,50);
player.addImage("running",player_running);
player.scale = 0.1;
  
  ground = createSprite(100,350,800,10);
ground.velocityX = -4;
  ground.x = ground.width/2;
  ground.visible = false;
  
  fruitGroup = new Group();
  obstacleGroup = new Group();
  
  score = 0;
}


function draw(){
 background(255); 
  
  if(ground.x < 0){
    ground.x = ground.width/2;
  }
  
  if(backgr.x < 100){
     backgr.x = backgr.width/2;
  }
  
  if(fruitGroup.isTouching (player)){
    fruitGroup.destroyEach();
    score = score + 2
  }
  
  switch(score){
    case 10: player.scale = 0.12;
      break;
    
    case 20: player.scale = 0.14;
      break;
    
    case 30: player.scale = 0.16;
      break;
    
    case 40: player.scale = 0.18;
      break;
      default: break;
  }
    
  if(keyDown("space")){
    player.velocityY = -10;
  }
  
  player.velocityY = player.velocityY + 0.8;

player.collide(ground);

  createFruit();
  createStone();
  
  if(obsatcleGroup.isTuching(player)){
     player.scale = 0.08;
     }

  drawSprites();
  
  stroke("white");
  textSize(20);
  fill("white");
text("score: " + score,20,380);

}

function createStone(){
if(frameCount % 300 === 0){
  var stone = createSprite(800,350,10,10);
  stone.addImage(obstacle_img);
  stone.scale = 0.1;
  stone.velocityX = -5;
  stone.lifetime = 300;
  obstacleGroup.add(stone);
}
}

function createFruit(){
if(frameCount % 80 === 0){
  var fruit = createSprite(800,250,40,10);
  fruit.y = random(120,200);
  fruit = addImage("bananaImage");
  fruit.scale = 0.05;
  fruit.velocityX = -5;
  
  fruit.lifetime = 300;
  player.depth = fruit.depth + 1;
  fruitGroup.add(fruit);
}
}